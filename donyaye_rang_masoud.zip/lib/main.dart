import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MyApp());
}

class Product {
  final String name;
  final String category;
  final double price;
  Product(this.name, this.category, this.price);
}

class ShopModel extends ChangeNotifier {
  List<Product> _products = [
    Product('رنگ قرمز', 'رنگ', 12000),
    Product('رنگ آبی', 'رنگ', 15000),
    Product('پنل چوبی', 'پنل', 45000),
  ];
  List<Product> get products => _products;

  String _categoryFilter = 'همه';
  String get categoryFilter => _categoryFilter;
  void setCategoryFilter(String cat) {
    _categoryFilter = cat;
    notifyListeners();
  }

  List<Product> get filteredProducts {
    if (_categoryFilter == 'همه') return _products;
    return _products.where((p) => p.category == _categoryFilter).toList();
  }

  List<Product> _cart = [];
  List<Product> get cart => _cart;

  void addToCart(Product p) {
    _cart.add(p);
    notifyListeners();
  }

  void removeFromCart(Product p) {
    _cart.remove(p);
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ShopModel(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'فروشگاه دنیای رنگ مسعود',
        theme: ThemeData(primarySwatch: Colors.blue),
        home: HomePage(),
        locale: Locale('fa'),
        supportedLocales: [Locale('fa'), Locale('en')],
        localizationsDelegates: [
          // Add localization delegates if needed
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var shop = Provider.of<ShopModel>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('فروشگاه دنیای رنگ مسعود'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) => shop.setCategoryFilter(v),
            itemBuilder: (_) => [
              PopupMenuItem(value: 'همه', child: Text('همه')),
              PopupMenuItem(value: 'رنگ', child: Text('رنگ')),
              PopupMenuItem(value: 'پنل', child: Text('پنل')),
            ],
            icon: Icon(Icons.filter_list),
          ),
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => CartPage()),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: shop.filteredProducts.length,
        itemBuilder: (_, i) {
          var p = shop.filteredProducts[i];
          return ListTile(
            title: Text(p.name),
            subtitle: Text('${p.price} تومان'),
            trailing: IconButton(
              icon: Icon(Icons.add_shopping_cart),
              onPressed: () => shop.addToCart(p),
            ),
          );
        },
      ),
    );
  }
}

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var shop = Provider.of<ShopModel>(context);
    return Scaffold(
      appBar: AppBar(title: Text('سبد خرید')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: shop.cart.length,
              itemBuilder: (_, i) {
                var p = shop.cart[i];
                return ListTile(
                  title: Text(p.name),
                  subtitle: Text('${p.price} تومان'),
                  trailing: IconButton(
                    icon: Icon(Icons.remove_shopping_cart),
                    onPressed: () => shop.removeFromCart(p),
                  ),
                );
              },
            ),
          ),
          Divider(),
          Text('جمع کل: ${shop.cart.fold(0, (sum, p) => sum + p.price)} تومان'),
          SizedBox(height: 10),
          ElevatedButton(
            child: Text('پرداخت (شبیه‌سازی)'),
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text('پرداخت انجام شد'),
                  content: Text('پرداخت به صورت شبیه‌سازی شده انجام شد.'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        shop.clearCart();
                        Navigator.of(context).pop();
                      },
                      child: Text('باشه'),
                    ),
                  ],
                ),
              );
            },
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}