
export const products = [
  { id: 1, name: 'رنگ قرمز', price: 100000 },
  { id: 2, name: 'رنگ آبی', price: 120000 },
];
