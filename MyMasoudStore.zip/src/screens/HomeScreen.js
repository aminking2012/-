
import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>فروشگاه دنیای رنگ مسعود 🎨</Text>
      <Button
        title="مشاهده محصولات"
        onPress={() => navigation.navigate('Product')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#f0e68c',
  },
  title: {
    fontSize: 22, fontWeight: 'bold', marginBottom: 20,
  }
});

export default HomeScreen;
