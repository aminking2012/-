
export const checkPassword = (password) => {
  return password === 'M1391b1391';
};
